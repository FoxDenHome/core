local M = {}

-- Filled in by build process
M.version = "2.1.3"

return M
